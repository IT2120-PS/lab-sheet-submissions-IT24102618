#1
setwd("C://Users//IT24102618//Desktop//IT24102618")
#2
Delivery_Times<-read.table("Exercise - Lab 05.txt",header= TRUE,sep=",")
#3
names(Delivery_Times)<-c("x1")
attach(Delivery_Times)
fix(Delivery_Times)
histogram<-hist(x1,main="Historgram for Deliver Times",breaks = seq(20, 70,length=10),right=TRUE)
#4
cumulative_freq <- cumsum(histogram$counts)
plot(histogram$mids, cumulative_freq, type="o", xlab="Delivery Time", ylab="Cumulative Frequency", 
     main="Cumulative Frequency Polygon (Ogive)", lwd=2)


