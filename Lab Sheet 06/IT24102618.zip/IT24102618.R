setwd("C://Users//Asus//Desktop//IT24102618")
#Q1
#Distribution of n=50 and p=0.85
pbinom(47,50,0.85,lower.tail = FALSE)
#Q2
#number of average calls recives per hour
#poisson Distribution
dpois(15,12)